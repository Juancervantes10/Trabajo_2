from experta import *
class reglas(Fact):
   
 pass